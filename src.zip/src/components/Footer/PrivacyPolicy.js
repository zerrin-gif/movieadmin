import React from 'react'
import Card from 'react-bootstrap/Card';
import Container from 'react-bootstrap/Container';
import Col from 'react-bootstrap/Col';
import Row from 'react-bootstrap/Row';

export default function PrivacyPolicy() {
    return (
        <Container className="footer-container">
            <div className='footer-card'>
                <div className='privacy-card-head'><h3>What is Lorem Ipsum?</h3></div>
                <div className='privacy-card-body'><p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p></div>
            </div>
            <div className='footer-card'>
                <div className='privacy-card-head'><h3>What is Lorem Ipsum?</h3></div>
                <div className='privacy-card-body'><p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p></div>
            </div>
            <div className='footer-card'>
                <div className='privacy-card-head'><h3>What is Lorem Ipsum?</h3></div>
                <div className='privacy-card-body'><p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p></div>
            </div>
            <div className='footer-card'>
                <div className='privacy-card-head'><h3>What is Lorem Ipsum?</h3></div>
                <div className='privacy-card-body'><p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p></div>
            </div>
            <div className='footer-card'>
                <div className='privacy-card-head'><h3>What is Lorem Ipsum?</h3></div>
                <div className='privacy-card-body'><p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p></div>
            </div>
            <div className='footer-card'>
                <div className='privacy-card-head'><h3>What is Lorem Ipsum?</h3></div>
                <div className='privacy-card-body'><p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p></div>
            </div>
            <div className='footer-card'>
                <div className='privacy-card-head'><h3>What is Lorem Ipsum?</h3></div>
                <div className='privacy-card-body'><p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p></div>
            </div>
        </Container>
        // <Container>
        //     <Row>
        //         <Col> 
        //         <Card>
        //             <Card.Header>Featured</Card.Header>
        //             <Card.Body>
        //                 <Card.Title>Special title treatment</Card.Title>
        //                 <Card.Text>
        //                     With supporting text below as a natural lead-in to additional content.
        //                 </Card.Text>
        //             </Card.Body>
        //         </Card>
        //          </Col>
        //      </Row>
        // </Container>
    )
}
