import React from 'react'
import './dashboard.css'

export default function Dashboard() {
    return (
        <div style={{margin:"500px"}}>
        <h1>This is dashboard.</h1> 
     </div>
    )
}
