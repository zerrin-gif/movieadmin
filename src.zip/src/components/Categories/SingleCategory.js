import React from 'react'
import './categories.css'

export default function SingleCategory() {
    return (
        <div>
            <h2>Single Category</h2>
        </div>
    )
}
