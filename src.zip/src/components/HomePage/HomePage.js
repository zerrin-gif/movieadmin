import React from 'react'
import './homepage.css'

export default function HomePage() {
    return (
        <div style={{margin:"500px"}}>
           <h1>This is homepage.</h1> 
        </div>
    )
}
