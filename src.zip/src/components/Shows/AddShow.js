import React from 'react'
import './shows.css'

export default function AddShow() {
    return (
        <div>
            <h1>Add Show</h1>
        </div>
    )
}
 