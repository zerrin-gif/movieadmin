import React from 'react'
import './shows.css'

export default function SingleShow() {
    return (
        <div>
            <h2>Single Show</h2>
        </div>
    )
}
 