import React from 'react'
import './ratings.css'

export default function SingleRating() {
    return (
        <div >
            <h2>Single Rating</h2>
        </div>
    )
}
